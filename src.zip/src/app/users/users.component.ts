import {Component} from '@angular/core';


@Component({
    selector: 'app-users',
    template: '<h2>Users</h2>'


  })

export class UsersComponent {

}
